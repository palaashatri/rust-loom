use loom_sheets_core::{export_xlsx_sheets, ChartKind, Sheet, SheetChart};

fn main() {
    let mut sanitized = Sheet::new("A/B");
    sanitized.set_str("A1", "Item");
    sanitized.set_str("B1", "Amount");
    sanitized.set_str("A2", "Rent");
    sanitized.set_str("B2", "10");
    sanitized.set_str("A3", "Food");
    sanitized.set_str("B3", "20");
    sanitized.chart = Some(SheetChart {
        kind: ChartKind::Line,
        cat_col: 0,
        val_col: 1,
        start_row: 1,
        end_row: Some(2),
        ..Default::default()
    });

    let mut collision = Sheet::new("AB");
    collision.set_str("A1", "30");

    let long_name = "Very Long Sheet Name That Exceeds 31 Characters";
    let mut long_sheet = Sheet::new(long_name);
    long_sheet.set_str("A1", "40");

    let mut consumer = Sheet::new("Consumer");
    consumer.set_str("A1", &format!("='A/B'!B2+'AB'!A1+'{long_name}'!A1"));
    consumer.set_str("A2", "=\"A/B!B2\"");

    let bytes = export_xlsx_sheets(&[sanitized, collision, long_sheet, consumer])
        .expect("export fixture with name collisions, references, and a chart");
    let output = std::env::args().nth(1).expect("output .xlsx path");
    std::fs::write(&output, &bytes).expect("write .xlsx fixture");
    println!("wrote {} bytes to {output}", bytes.len());
}
