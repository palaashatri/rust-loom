from pathlib import Path
import sys
from zipfile import ZipFile
import xml.etree.ElementTree as ET

path = (
    Path(sys.argv[1])
    if len(sys.argv) > 1
    else Path(__file__).with_name("lo-fixed") / "loom-interop-matrix-fixed.ods"
)
ns = {
    "office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
    "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
    "style": "urn:oasis:names:tc:opendocument:xmlns:style:1.0",
    "fo": "urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0",
    "draw": "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0",
    "number": "urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0",
}

def attr(node, namespace, name):
    return node.get(f"{{{ns[namespace]}}}{name}")

def cell(table, row_number, column_number):
    row = table.findall(".//table:table-row", ns)[row_number - 1]
    return row.findall("table:table-cell", ns)[column_number - 1]

with ZipFile(path) as archive:
    content = ET.fromstring(archive.read("content.xml"))
    styles = ET.fromstring(archive.read("styles.xml"))
    tables = content.findall(".//table:table", ns)
    names = [attr(table, "table", "name") for table in tables]
    assert names == ["AB", "AB (2)", "Very Long Sheet Name That Excee", "Consumer"], names

    ab = tables[0]
    total = cell(ab, 4, 2)
    assert attr(total, "office", "value-type") == "currency", total.attrib
    assert attr(total, "office", "value") == "30", total.attrib
    total_style_name = attr(total, "table", "style-name")
    assert total_style_name, total.attrib
    total_style = next(
        item for item in content.findall(".//style:style", ns)
        if attr(item, "style", "name") == total_style_name
    )
    style_children = {child.tag.rsplit("}", 1)[-1]: child for child in total_style}
    cell_props = style_children["table-cell-properties"].attrib
    text_props = style_children["text-properties"].attrib
    paragraph_props = style_children["paragraph-properties"].attrib
    assert cell_props.get(f"{{{ns['fo']}}}background-color") == "#fef08a", cell_props
    assert "solid" in cell_props.get(f"{{{ns['fo']}}}border", ""), cell_props
    assert text_props.get(f"{{{ns['fo']}}}font-weight") == "bold", text_props
    assert paragraph_props.get(f"{{{ns['fo']}}}text-align") == "end", paragraph_props
    number_style_name = attr(total_style, "style", "data-style-name")
    number_style = next(
        item for item in styles.iter()
        if item.tag == f"{{{ns['number']}}}currency-style"
        and attr(item, "style", "name") == number_style_name
    )
    number = number_style.find("number:number", ns)
    assert number is not None and attr(number, "number", "decimal-places") == "2"

    consumer = tables[3]
    expected = [(1, "80"), (2, "30"), (3, "60")]
    for row_number, value in expected:
        result = cell(consumer, row_number, 1)
        assert attr(result, "office", "value") == value, result.attrib
        assert attr(result, "table", "formula"), result.attrib
    literal = cell(consumer, 4, 1)
    assert "A/B!B2" in "".join(literal.itertext())

    labels = ["".join(node.itertext()).strip() for node in content.iter()
              if node.tag.endswith("}p") and "".join(node.itertext()).strip()]
    assert "Quarterly target" in labels, labels
    chart_frames = [node for node in content.findall(".//draw:frame", ns)
                    if attr(node, "draw", "name") == "Chart 1"]
    assert chart_frames, "chart frame missing from converted workbook"
    chart_files = [name for name in archive.namelist()
                   if name.startswith("Object ") or "chart" in name.lower()]
    assert chart_files, "embedded chart parts missing from converted workbook"

print("PASS: four sheet names, styled currency total (fill/bold/border/alignment/2 decimals), three recalculated cross-sheet formulas, literal text, chart, and shape label survived LibreOffice Calc 24.2 XLSX→ODS conversion")
