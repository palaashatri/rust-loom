use loom_sheets_core::style::FillColor;
use loom_sheets_core::{
    export_xlsx_sheets, CellAlignment, CellRef, CellStyle, ChartKind, NumberFormat, Sheet,
    SheetChart, SheetObject,
};

fn main() {
    let mut sanitized = Sheet::new("A/B");
    sanitized.set_str("A1", "Item");
    sanitized.set_str("B1", "Amount");
    sanitized.set_str("A2", "Rent");
    sanitized.set_str("B2", "10");
    sanitized.set_str("A3", "Food");
    sanitized.set_str("B3", "20");
    sanitized.set_str("A4", "Total");
    sanitized.set_str("B4", "=SUM(B2:B3)");
    let mut total_style = CellStyle::default();
    total_style.bold = true;
    total_style.border = true;
    total_style.fill = FillColor::Yellow;
    total_style.number_format = NumberFormat::Currency;
    sanitized.set_cell_style(CellRef { row: 3, col: 1 }, total_style);
    sanitized.set_cell_alignment(CellRef { row: 3, col: 1 }, CellAlignment::Right);
    sanitized.set_col_width(1, 150.0);
    sanitized.set_row_height(3, 30.0);
    sanitized.chart = Some(SheetChart {
        kind: ChartKind::Line,
        cat_col: 0,
        val_col: 1,
        start_row: 1,
        end_row: Some(2),
        ..Default::default()
    });

    let mut collision = Sheet::new("AB");
    collision.set_str("A1", "30");
    collision
        .objects
        .push(SheetObject::shape(CellRef { row: 2, col: 2 }, "Quarterly target"));

    let long_name = "Very Long Sheet Name That Exceeds 31 Characters";
    let mut long_sheet = Sheet::new(long_name);
    long_sheet.set_str("A1", "40");

    let mut consumer = Sheet::new("Consumer");
    consumer.set_str(
        "A1",
        &format!("='A/B'!B2+'AB'!A1+'{long_name}'!A1"),
    );
    consumer.set_str("A2", "=SUM('A/B'!B2:B3)");
    consumer.set_str("A3", "=SUM('A/B'!B2:B3)*2");
    consumer.set_str("A4", "A/B!B2");

    let bytes = export_xlsx_sheets(&[sanitized, collision, long_sheet, consumer])
        .expect("export style, formula, chart, shape, and name-collision fixture");
    let output = std::env::args().nth(1).expect("output .xlsx path");
    std::fs::write(&output, &bytes).expect("write .xlsx fixture");
    println!("wrote {} bytes to {output}", bytes.len());
}
