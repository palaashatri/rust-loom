use loom_sheets_core::{CellRef, import_xlsx_sheets};

fn main() {
    let path = std::env::args().nth(1).expect("Calc-generated .xlsx input");
    let bytes = std::fs::read(&path).expect("read Calc-generated .xlsx");
    let imported = import_xlsx_sheets(&bytes).expect("import Calc-generated workbook");
    println!("sheets={} warnings={:?}", imported.sheets.len(), imported.warnings);
    for sheet in &imported.sheets {
        println!("sheet={:?}", sheet.name);
        for cell_name in ["B4", "A1", "A2", "A3", "A4"] {
            let cell = CellRef::parse(cell_name).expect("cell reference");
            if let Some(value) = sheet.cells.get(&cell) {
                println!("  {cell_name}={:?}", value.raw);
            }
        }
        if sheet.name == "AB" {
            let cell = CellRef::parse("B4").unwrap();
            println!("  B4-style={:?}", sheet.cell_style(cell));
            println!("  B4-alignment={:?}", sheet.cell_alignment(cell));
            println!("  chart={:?}", sheet.chart);
        }
        if sheet.name == "AB (2)" {
            println!("  object-labels={:?}", sheet.objects.iter().map(|o| &o.label).collect::<Vec<_>>());
        }
    }
}
