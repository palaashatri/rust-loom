# XLSX style interoperability probe

LibreOffice Calc 24.2.7.2 converted Loom's exported XLSX fixture to ODS. The original package contains `xl/styles.xml`, a content-type override, and a worksheet style index on B4, but `xl/_rels/workbook.xml.rels` has no relationship to the styles part. The converted ODS therefore gave B4 no cell style.

A diagnostic copy with `applyFont`, `applyFill`, `applyBorder`, and `applyNumberFormat` added to the XF still lost the style. A second diagnostic copy with only a workbook relationship to `styles.xml` retained the cell style and currency value. This isolated the package relationship as the cause.

After the exporter fix, the full generated fixture converted successfully. `assert_ods.py` verifies all four sheet names, the B4 yellow fill/bold/border/right alignment/two-decimal currency format, three cross-sheet formula results (80, 30, 60), literal `A/B!B2` text, the chart frame, and the shape label. This is evidence for this fixture and Calc version only; it is not a full Excel or interoperability certification.
