# Sheets acceptance evidence — 2026-09-22

This report records the repaired Sheets template chooser, the current viewport/theme captures, and the existing data-integrity evidence. It does not claim acceptance for checks that require a physical desktop pointer or a screen reader.

## Repaired chooser behavior

The template chooser now:

- wraps template cards into a vertically scrollable content region;
- keeps Recents tied to templates created in the current session and says `No recent templates` when empty;
- exposes all categories in All Templates, including Personal, Business, and Education;
- lets Left/Right select the visible category's cards with wrap-around;
- moves the scroll target with the selected card, including at 1.25× and 1.5× text scale;
- uses Return/Create for the selected card and Escape/Cancel without replacing the current workbook.

The focused Slint interaction test renders selected Invoice & Expenses cards at 1.0×, 1.25×, and 1.5×. At the two required accessibility sizes, the complete preview, title, section heading, and footer actions are visible in the 1024×720 capture.

Evidence:

- `screenshots/1024x720-template-chooser-1.25.png`
- `screenshots/1024x720-template-chooser-1.5.png`
- `screenshots/1024x720-template-chooser-text-200-current.png` (exploratory 2.0× capture)
- `/tmp/loom-sheets-template-chooser-keyboard-selection-1.0.png`
- `/tmp/loom-sheets-template-chooser-keyboard-selection-1.25.png`
- `/tmp/loom-sheets-template-chooser-keyboard-selection-1.5.png`

## Viewport and theme evidence

The fresh debug binary was built from the current working tree after the chooser repair and split. Its SHA-256 is `383ff06676dfda18ad835d81cd0f0cf205ebd61a6324891b4965808e17fd4d5c`.

Fresh headless captures were generated at 1024×720, 1280×800, 1440×900, and 1920×1200 in light, dark, and high-contrast themes. All 12 commands exited 0 and produced PNGs with the requested dimensions and plausible file sizes. The contact sheet is `screenshots/sheets-viewport-theme-contact.png`.

The captures show the blank workbook, readable chrome, a closed inspector by default, the grid, formula bar, tabs, and status bar. The dark and high-contrast variants remain visually distinct and keep the active-cell outline visible.

## Tests and checks

- `PKG_CONFIG_PATH=/tmp/loom-writer-fontconfig-deps/pkgconfig-dynamic cargo test --locked --offline -p loom-sheets-app`: **109 passed, 0 failed**.
- `cargo test --locked --offline -p loom-sheets-core`: **87 core tests, 13 formula tests, 1 performance test, and 4 range tests passed**.
- `cargo fmt --manifest-path loom-sheets/Cargo.toml --all`: passed.
- `git diff --check`: passed.
- `python3 loom-bootstrap/scripts/audit-governance.py`: passed.
- `python3 loom-bootstrap/scripts/audit-ui-foundation.py`: passed.
- The active Sheets source-size ceiling passes after moving chooser navigation to `template_navigation.rs`; the structure audit still reports pre-existing over-budget locked apps (Encode, Motion, Video, Writer core, and Photo).

The app tests cover template creation, real Recents, Escape cancellation, keyboard focus paths, workbook Save/Open and XLSX round trips, chart ranges, undo/redo, formula editing, and inspector state. The compact inspector regression is recorded in `inspector-keyboard-tests.log`; it covers Escape dismissal, focus restoration to Format, Tab/Enter Close, and selection preservation. The chooser keyboard path is verified through Slint window key events and rendered output. A physical desktop keyboard/pointer run and screen-reader output remain unverified in this environment, so the overall Sheets application stays acceptance-blocked until those checks are performed.
