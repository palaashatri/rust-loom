# Sheets acceptance evidence — 2026-09-22

This report records the chart-range repair and current chooser visuals. It does not certify the Sheets application as accepted.

## What was checked

The screenshot commands in `capture-manifest.json` were rerun against the existing app binary. All 15 commands exited 0 and produced the requested PNG sizes. The binary SHA-256 is `9802553756ee279318048e09cbaf78f3fa28ad47ed8ee3fcc889e51e0a4119eb`. It was built at 2026-09-22 11:22 local time; these captures are rendered by that cached binary, not a fresh build from the current working tree.

I inspected the 1024×720 and 1440×900 chart captures and the 1024×720 template chooser capture. The chart shows source `A1:B4`, series `Amount`, unit `USD/month`, and only Rent, Food, and Transport. The amount header is fully readable at both sizes. The chooser shows truthful empty Recents, full names for visible cards, and the category rail and Cancel/Create actions inside the window. Lower template cards continue below the visible scroll area.

![Sheets chart at 1024×720](screenshots/1024x720-chart.png)

![Sheets chart at 1440×900](screenshots/1440x900-chart.png)

![Template chooser at 1024×720](screenshots/1024x720-template-chooser.png)

## Test evidence

Ran existing compiled Rust test harnesses directly; no cargo build, test compilation, or dependency setup was run:

- Sheets app harness: 101 passed, 0 failed.
- Sheets core harness: 87 passed, 0 failed.
- Formula evaluation harness: 13 passed, 0 failed.
- Performance harness: 1 passed, 0 failed.
- Range harness: 4 passed, 0 failed.
- Total: 206 passed, 0 failed.
- `git diff --check`: passed.

The app tests cover selected chart bounds, labels/units, live update, Undo, native workbook Save/Open, and explicit inclusion of Total. The core test covers XLSX chart-range round-trip.

## Still open

The template-card keyboard path (focus, selection, and activation) and 1.25×/1.5× text scaling were not verified. The screenshots do not prove keyboard order, screen-reader output, or native interaction. A fresh local build is blocked because `pkg-config --modversion fontconfig` reports that `fontconfig.pc` is missing. The new Sheets CI job installs `libfontconfig1-dev`; its pushed run still needs to pass.

The governance and UI-foundation source audits passed. The code-structure ratchet failed on four unchanged files outside the active Sheets scope: `loom-encode/crates/loom-encode-app/src/main.rs`, `loom-video/crates/loom-video-app/src/main.rs`, `loom-video/crates/loom-video-core/src/lib.rs`, and `loom-photo/crates/loom-photo-app/src/main.rs`. This finding is recorded without editing those locked apps.

The earlier `chart-range-fault-injection.log` records the deliberate regression run where XLSX output dropped the explicit range. That run failed at the expected `$A$2:$A$4` assertion. The stale injected-fault binary is not counted as a current-source failure; the newer cached core harness passed.
