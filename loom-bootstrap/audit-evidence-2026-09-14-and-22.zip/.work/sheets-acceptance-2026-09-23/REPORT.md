# Native screenshot self-audit — 2026-09-23

This report adds screenshots taken from the running desktop Sheets binary with the native `/usr/bin/gnome-screenshot` utility. The captures are visual evidence only; they do not prove pointer, keyboard, or screen-reader behavior.

## Capture setup

- Binary: `loom-sheets/target/debug/loom-sheets`
- Binary SHA-256: `383ff06676dfda18ad835d81cd0f0cf205ebd61a6324891b4965808e17fd4d5c`
- Backend: `SLINT_BACKEND=software` on `DISPLAY=:0`
- Screenshot command: `gnome-screenshot -w -f <path>`
- Requested window: 1024×720; native screenshots include the 8-pixel window decoration and are 1024×728.

## Observations

- Light chooser at 1.25× keeps the full card previews, names, category labels, and footer actions inside the window. The rightmost card is not sliced.
- Dark chooser at 1.5× keeps the larger heading, card names, sidebar labels, and Cancel/Create actions readable. The empty Recents message is truthful.
- Light and high-contrast blank workbooks keep the formula bar, grid headers, active-cell outline, tabs, and Offline status visible. High-contrast header text remains readable against its dark header fill.
- The compact layout uses the full width for the grid and keeps the Format action discoverable in the toolbar.

## Files

- `native/chooser-1024-scale125-native.png`
- `native/chooser-1024-scale150-native.png`
- `native/blank-1024-light-native.png`
- `native/blank-1024-high-contrast-native.png`

A 1440×900 native capture was not possible on this 1366×728 desktop; the required 1440×900 state remains covered by the existing headless evidence. This screenshot pass does not change the open native pointer/keyboard or screen-reader acceptance status.
