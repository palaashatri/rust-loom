# Native Sheets self-audit — 2026-09-23

This report records visual captures and keyboard/accessibility checks from the live Linux Sheets window. The screenshots were taken with `/usr/bin/gnome-screenshot`, not rendered by the headless preview path.

## Capture setup

- Binary: `loom-sheets/target/debug/loom-sheets`
- Binary SHA-256: `a19bd5a2994b3f5fbf511001b134352564af9a409192654db7fa8e55889207b3`
- Backend: `SLINT_BACKEND=software` on `DISPLAY=:0`
- Screenshot command: `/usr/bin/gnome-screenshot -w -f <path>`
- Requested window: 1024×720; PNG captures include the native title bar and are 1024×741.
- Orca 46.1 and the AT-SPI tree were enabled for the accessibility checks. The temporary accessibility settings were restored after the run.

## Results

- The reopened `.loomtable` shows the saved A2 value `groceries` and the correct filename in its title. The earlier native save/open flow created and reopened this file through the desktop file picker.
- A native keyboard edit changed A2 to `vegetables`; the window title gained `*`. AT-SPI reported `A2 selected; value: vegetables; formula: vegetables` on the focused `Example Budget worksheet grid`. The unsaved test edit was not written to the sample file.
- The compact toolbar export icon now has the accessible name `Export CSV` and description `Export the active worksheet as CSV`.
- On chooser launch, AT-SPI reports the named `Template chooser` group focused with the selected-template instructions. Right changes the description to `Checklist selected. Use Left and Right to choose; Return creates it; Escape cancels.` Orca's speech log confirms it spoke that text.
- Return creates the selected Checklist workbook, whose sample rows and formulas are visible. Focus returns to the named `Checklist worksheet grid` group.
- Escape closes the chooser without changing the existing workbook and restores focus to its worksheet grid. The post-cancel screenshot matches the opened-workbook screenshot by SHA-256.
- The chooser and workbook layouts fit in the native 1024×720 window at 1.25× text scale. Older native captures still document the light, dark, and high-contrast blank/chooser states.

## Native screenshots

These app-only captures are also checked into `loom-sheets/docs/qa-native/`:

- `opened-saved-workbook-linux.png` — reopened saved file, including A2 `groceries`.
- `unsaved-edit-title-linux.png` — edited A2 and visible `*` dirty marker.
- `template-chooser-checklist-selected-linux.png` — selected Checklist card.
- `template-cancel-preserves-workbook-linux.png` — Escape returns to the unchanged saved workbook.
- `template-created-checklist-linux.png` — Return creates the Checklist workbook.

## Limits

This is one Linux desktop at 1024×720 in the light theme. A native 1440×900 capture is not possible on the 1366×728 display; larger viewports and the other themes remain covered only by existing renderer evidence. These checks do not cover every dialog failure/cancellation path, representative large-workbook performance, all keyboard commands, or complete screen-reader coverage. They do not by themselves accept Sheets.

## UI-06 status and error feedback — 2026-09-23

The status feedback follow-up was checked in the live Linux app. The final build keeps formula errors visible after grid projection, keeps the cell/formula count in a separate status field, and makes the visible error text a polite accessibility live region. Read-only save errors are shortened to a direct message.

- `loom-sheets/docs/qa-native/ui06-formula-error-live-status-linux.png` — invalid `=1/0` formula, visible `#DIV/0!`, status `Formula error in A1: #DIV/0!`, and separate cell/formula count. Native window capture: 1024×752.
- `loom-sheets/docs/qa-native/ui06-readonly-save-failure-live-status-linux.png` — read-only destination, concise `Save failed: destination is read-only`, and the dirty `*` retained. Native window capture: 1024×752.
- `loom-sheets/docs/qa-native/ui06-save-cancel-dirty-workbook-linux.png` — Save As canceled, status `Save cancelled`, and dirty `*` retained. This capture and screen-reader check are from the native run immediately before the status-summary separation; the Save-cancel callback was unchanged by that separation.

Verification recorded for the final status build: `cargo test --manifest-path loom-sheets/Cargo.toml --locked --offline -q -p loom-sheets-app` passed 112 tests, and `cargo build --manifest-path loom-sheets/Cargo.toml --locked --offline -p loom-sheets-app` succeeded. The focused checks are `formula_errors_are_visible_in_a_polite_live_region` and `readonly_save_error_feedback_is_short_and_actionable`. Anchored Orca log records contain exactly one speech event for the formula error, one for the read-only save error, and one for the canceled Save As message. The raw temporary logs are not retained; the filtered counts and native captures are the evidence. Orca and the speech-dispatcher backend were stopped and temporary accessibility settings restored after the checks.
